//
//  main.swift
//  EjerciciosDoConsola
//
//  Created by Enmanuel on 10/9/23.
//

import Foundation

/*
 
 Ejercicios desarrollados por:
    Julio Enmanuel Ortiz Romero
    25-0202-2019
    Ingenieria en Sistemas
 
 Indicaciones:
    - Para ejecutar este codigo, por favor pegarlo en el archivo main, ya que aun no se hha trabajado con llamada de objetos, funciones y estructura de codigo en swift.
 */

// Pegar aqui abajo el ejercicio que desea ejecutar

