//
//  main.swift
//  EjerciciosIfConsola
//
//  Created by Enmanuel on 3/9/23.
//

import Foundation

/*
 
 Ejercicios desarrollados por:
    Julio Enmanuel Ortiz Romero
    25-0202-2019
    Ingenieria en Sistemas

*/

// Pegar aqui abajo el ejercicio que desea ejecutar

