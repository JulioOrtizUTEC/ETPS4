//
//  Ejercicio 2.swift
//  EjerciciosIfConsola
//
//  Created by Enmanuel on 3/9/23.
//

import Foundation

/*
 
 Ejercicios desarrollados por:
    Julio Enmanuel Ortiz Romero
    25-0202-2019
    Ingenieria en Sistemas

*/

/*
 Ejercicio 2
 
 Se declaran cinco notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje ”Aprobado ETPS4”.
 */

/* Eliminar esta linea para correr el proyeto

 print("Ingrese la nota 1:")
 var nota1 = Double(readLine()!)!
 print("Ingrese la nota 2:")
 var nota2 = Double(readLine()!)!
 print("Ingrese la nota 3:")
 var nota3 = Double(readLine()!)!
 print("Ingrese la nota 4:")
 var nota4 = Double(readLine()!)!
 print("Ingrese la nota 5:")
 var nota5 = Double(readLine()!)!

 //Se calcula el promedio
 let promedio = (nota1 + nota2 + nota3 + nota4 + nota5) / 5
 //Se evalua el resultado

 if(promedio >= 7){
     print("Aprobado ETPS4")
 }else{
     print("Reprobado ETPS4")
 }

// Fin del ejercicio 2
 
 Eliminar esta linea para correr el proyeto */
