//
//  Ejercicio 3.swift
//  EjerciciosIfConsola
//
//  Created by Enmanuel on 3/9/23.
//

import Foundation

/*
 
 Ejercicios desarrollados por:
    Julio Enmanuel Ortiz Romero
    25-0202-2019
    Ingenieria en Sistemas
 
 Indicaciones:
    - Para ejecutar este codigo, por favor pegarlo en el archivo main, ya que aun no se hha trabajado con llamada de objetos, funciones y estructura de codigo en swift.
 */

/*
 Ejercicio 3
 
 Realizar un programa que solicite declarar dos números distintos y muestre por pantalla el mayor de ellos.
 
 */

/* Eliminar esta linea para correr el proyeto

var num1 = 0
var num2 = 0

print("Ingresar el primer digito:")
num1 = Int(readLine()!)!
print("Ingresar el segundo digito")
num2 = Int(readLine()!)!

if (num1>num2){
    print("El numero mayor es:",num1)
}else{
    if (num1 == num2){
        print("Ambos numeros son iguales")
    }else{
        print("El numero mayor es:",num2)
    }
}

// Fin del ejercicio 3

Eliminar esta linea para correr el proyeto */
