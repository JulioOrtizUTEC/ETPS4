//
//  Ejercicio 1.swift
//  EjerciciosIfConsola
//
//  Created by Enmanuel on 3/9/23.
//

import Foundation

/*
 
 Ejercicios desarrollados por:
    Julio Enmanuel Ortiz Romero
    25-0202-2019
    Ingenieria en Sistemas

*/

/*
 Ejercicio 1
 
 Ingresar el sueldo de una persona, si supera los $3000 mostrar un mensaje en la salida indicando que debe abonar impuestos.
 */

/* Eliminar esta linea para correr el proyeto
 
var sueldo = 0.00

print("Ingrese el sueldo:")
sueldo = Double(readLine()!)!

if(sueldo > 3000){
    print("Debe abonar impuestos")
}else{
    print("No debe abonar impuestos")
}
 
 // Fin Ejercicio 1
 
 Eliminar esta linea para correr el proyeto */
