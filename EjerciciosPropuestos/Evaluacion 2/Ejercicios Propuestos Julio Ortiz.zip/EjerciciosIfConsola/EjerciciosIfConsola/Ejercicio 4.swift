//
//  Ejercicio4.swift
//  EjerciciosIfConsola
//
//  Created by Enmanuel on 3/9/23.
//

import Foundation

/*
 
 Ejercicios desarrollados por:
    Julio Enmanuel Ortiz Romero
    25-0202-2019
    Ingenieria en Sistemas
*/
 
/*
 Ejercicio 4
 
 Realizar un programa que declarado dos números, si el primero es mayor al segundo informar su suma y diferencia, en caso contrario informar el producto y la división del primero respecto al segundo.
 
 */

/* Eliminar esta linea para correr el proyeto
 
var dato1 = 0.00
var dato2 = 0.00

print("Ingrese el primer digito:")
dato1 = Double(readLine()!)!
print("Ingrese el segundo digito:")
dato2 = Double(readLine()!)!

if(dato1 > dato2){
    print("La suma entre",dato1,"+",dato2,"es:",(dato1 + dato2))
    print("La resta entre",dato1,"-",dato2,"es:",(dato1 - dato2))
}else{
    print("La multiplicacion entre",dato1,"*",dato2,"es:",(dato1 * dato2))
    print("La division entre",dato1,"/",dato2,"es:",(dato1 / dato2))
}

// Fin del ejercicio 4

Eliminar esta linea para correr el proyeto */
