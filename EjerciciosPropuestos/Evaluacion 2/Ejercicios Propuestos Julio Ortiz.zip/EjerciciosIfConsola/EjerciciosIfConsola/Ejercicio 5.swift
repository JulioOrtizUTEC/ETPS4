//
//  Ejercicio 5.swift
//  EjerciciosIfConsola
//
//  Created by Enmanuel on 3/9/23.
//

import Foundation

/*
 Ejercicio 5
 
 Se declara un número positivo de uno o dos dígitos (1..99) mostrar un mensaje indicando si el número tiene uno o dos dígitos.
 (Tener en cuenta que condición debe cumplirse para tener dos dígitos, un número entero
 
 */

/* Eliminar esta linea para correr el proyeto

var numero = 0

print("Ingrese el digito:")
numero = Int(readLine()!)!

if (numero <= 9){
    print("El numero tiene 1 digito")
}else{
    if(numero > 9 && numero <= 99){
        print("El numero tiene 2 digitos")
    }else{
        print("Numero fuera de rango")
    }
}

// Fin del ejercicio 5

Eliminar esta linea para correr el proyeto */
