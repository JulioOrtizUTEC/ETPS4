//
//  Ejercicio2.swift
//  EjerciciosWhileConsola
//
//  Created by Enmanuel on 10/9/23.
//

import Foundation

/*
 
 Ejercicios desarrollados por:
    Julio Enmanuel Ortiz Romero
    25-0202-2019
    Ingenieria en Sistemas

*/

/*
 Ejercicio 2

 Una planta que fabrica perfiles de hierro posee un lote de n piezas. Confeccionar un programa que pida ingresar por teclado la cantidad de piezas a procesar y luego ingrese la longitud de cada perfil; sabiendo que la pieza cuya longitud esté comprendida en el rango de 1,20 y 1,30 son aptas. Imprimir por pantalla la cantidad de piezas aptas que hay en el lote.
*/

/* Eliminar esta linea de comentario
var totalPiezas:Int = 0;
var i:Int = 1;
var longitudPieza:Double = 0.00;
var piezasAptas:Int = 0;

print("Digite el total de piezas a procesar:")
totalPiezas = Int(readLine()!)!

while(i <= totalPiezas){
    print("Ingrese la longitud de la pieza \(i)")
    longitudPieza = Double(readLine()!)!
    
    if (longitudPieza >= 1.20 && longitudPieza <= 1.30){
        piezasAptas = piezasAptas + 1
    }
    
    i = i + 1
}

print("El total de piezas aptas dentro del lote es de: \(piezasAptas)")
 
Eliminar esta linea de comentario */
